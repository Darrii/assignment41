from flask import Flask,request, render_template, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import redirect
from ArticleFinder import Finder


app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blogs.db' 
db = SQLAlchemy(app)


class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    url = db.Column(db.String(300), nullable=False)
    coin = db.Column(db.String(100), nullable=False)


@app.route('/coin')
def index():
    return render_template('index.html')
@app.route('/find', methods=['POST'])
def find():
    if request.method == "POST":
        scrapper = Finder()
        name = request.form['name']
        articles = scrapper.findArticle(name)
        counter = 0
        for article in articles:
            article = Article(url=article, coin=name)
            try:
                db.session.add(article)
                db.session.commit()
            except:
                print("Something went wrong")
                pass
        return render_template('index.html', articles=articles, name=name)

@app.route('/db')
def df():
    data = Article.query.all()
    return render_template('index.html', data=data)

@app.route('/db_delete_all')
def db_detete_all():
    try:
        num_rows_deleted = db.session.query(Article).delete()
        db.session.commit()
    except:
        db.session.rollback()
    return render_template('index.html', data=None, num_rows_deleted=num_rows_deleted)
if __name__ == "__main__":
    app.run(debug=True)

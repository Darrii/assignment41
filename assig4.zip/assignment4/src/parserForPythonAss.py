
from ArticleFinder import Finder

scrapper = Finder()
lists = scrapper.findArticle("bitcoin")
for i in lists:
    print(i)
print("\nTOTAL AMOUNT OF sites: " + str(len(lists)))


# python-assignment-4

## Installation
1. clone this repo
2. install requirements `pip install -r requirements.txt`

## Usage
Open the command line and type ```python app.py``` to run application.
## Examples
```python app.py```
Open http://127.0.0.1:5000 using your browser. We have 4 routes. The main route is '/coin'  that has  input of some name of cryptocurrency. I have only one template of HTML file which named "index.html". Then I have "/find" which have method allowed only "POST". Which have scrapper that finds all blogs or news and first of all it saves it then return the template with listes of news. Also we have '/db' route that shows the whole database within stored news and blogs. It has opportunity to delete all rows from database by going to '/db_delete_all'. 
    To use application just go to '/coin' enter the name of crypto then press button 'send' after that you will receive all news in that WebPage.
    

## License
MIT
